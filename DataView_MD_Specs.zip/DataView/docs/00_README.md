# DataView

아이폰의 셀룰러 데이터 사용량을 한눈에 확인하고, 가능한 환경에서는 핫스팟 사용량까지 분리해 보여주는 iOS 앱 + WidgetKit 프로젝트.

> 디자인 기준: 사용자가 확정한 DataView 시안  
> 주요 키워드: iOS-native, clean, blue, compact, glanceable, privacy-first

---

## 1. 제품 목표

사용자가 설정 앱을 여러 단계 열지 않고도 홈 화면과 잠금 화면에서 아래 정보를 빠르게 확인할 수 있게 한다.

- 이번 데이터 주기 전체 사용량
- 남은 데이터
- 사용률
- 오늘 사용량
- 최근 7일 사용량
- 셀룰러 사용량
- 가능한 경우 핫스팟 사용량
- 데이터 사용량 경고
- Small / Medium / Lock Screen 위젯

---

## 2. 핵심 원칙

1. **첫 화면에서 남은 데이터가 가장 크게 보일 것**
2. 위젯에서 필요한 정보는 3초 안에 읽을 수 있을 것
3. Apple 공개 API만 사용한다.
4. Private API, 비공개 설정 접근, App Store 심사 위험이 큰 우회 방식은 사용하지 않는다.
5. 통신사 청구량과 완전히 동일하다고 표현하지 않는다.
6. 핫스팟 분리는 실제 기기에서 안정적으로 검증된 경우에만 노출한다.
7. 기기별 핫스팟 사용량은 공식 공개 API가 확인되지 않으므로 MVP 필수 기능으로 잡지 않는다.

---

## 3. 권장 기술 스택

- Swift 6+
- SwiftUI
- WidgetKit
- App Intents (필요 시)
- App Groups
- SwiftData 또는 SQLite
- UserDefaults(suiteName:) — 위젯 요약값 공유
- Darwin `getifaddrs()` + `if_data64` — 네트워크 인터페이스 바이트 카운터 읽기
- BackgroundTasks — 보조 갱신
- UserNotifications — 사용량 경고

최소 지원 버전 권장:

- iOS 17.0+
- Xcode 최신 정식 버전 기준
- 실제 테스트 기기: 최신 iOS 26.x 포함

---

## 4. 문서 목록

| 파일 | 목적 |
|---|---|
| `01_PRODUCT_REQUIREMENTS.md` | 제품 요구사항 및 MVP 범위 |
| `02_UI_WIREFRAME.md` | 화면별 와이어프레임 |
| `03_WIDGET_SPEC.md` | 홈/잠금화면 위젯 상세 명세 |
| `04_DESIGN_SYSTEM.md` | 색상, 타이포, 컴포넌트 |
| `05_DATA_MODEL.md` | 로컬 데이터 구조 |
| `06_IOS_ARCHITECTURE.md` | Swift 프로젝트 구조 및 아키텍처 |
| `07_MEASUREMENT_STRATEGY.md` | 셀룰러/핫스팟 측정 전략과 제약 |
| `08_IMPLEMENTATION_PLAN.md` | Codex 구현 순서 |
| `09_ACCEPTANCE_TESTS.md` | 완료 판정 기준 및 테스트 케이스 |

---

## 5. 최종 사용자 플로우

```text
앱 실행
  ↓
스플래시
  ↓
온보딩
  ↓
요금제 설정
  ├─ 월 데이터 용량
  ├─ 초기화일
  └─ 알림 기준
  ↓
메인 대시보드
  ├─ 남은 데이터
  ├─ 총 사용량
  ├─ iPhone 사용량
  ├─ 핫스팟 사용량(지원 시)
  └─ 최근 사용 추이
  ↓
통계
  ├─ 일별
  ├─ 주별
  └─ 월별
  ↓
핫스팟 상세
  ├─ 전체 사용량
  ├─ 최근 추이
  └─ 기기별 목록(실험/추후)
```

---

## 6. 프로젝트에서 반드시 지킬 문구

### 표시 가능

- `이번 달 72.4 GB 사용`
- `87.6 GB 남음`
- `앱 측정 기준`
- `최근 갱신 20:14`

### 금지

- `통신사 공식 사용량`
- `SKT와 100% 동일`
- `정확한 핫스팟 기기별 사용량` — 공식 API가 없는 상태에서는 금지
- 지원 검증 없이 `MacBook 8.4 GB` 같은 값을 실측값처럼 표시

---

## 7. Graceful Degradation

핫스팟 분리가 불가능한 기기/OS에서는 UI가 깨지지 않아야 한다.

```text
[정상]
iPhone      54.2 GB
핫스팟      18.2 GB

[핫스팟 분리 미지원]
셀룰러 전체 72.4 GB
핫스팟      분리 측정 미지원
```

Medium Widget에서는 핫스팟 카드 대신 `오늘 사용량` 카드를 보여준다.
