# DataView Widget Specification

## 1. 지원 Widget Family

MVP:

- `.systemSmall`
- `.systemMedium`
- `.accessoryCircular`
- `.accessoryRectangular`

선택:

- `.accessoryInline`

---

# 2. Small Widget

## 목적

`남은 데이터` 하나를 가장 빠르게 확인.

```text
┌─────────────────┐
│ ▂▄▆  데이터      │
│                 │
│    ╭──────╮     │
│   ╱        ╲    │
│  │ 87.6 GB │    │
│  │   남음   │    │
│   ╲        ╱    │
│    ╰──────╯     │
│     45% 사용     │
└─────────────────┘
```

## 표시 데이터

- remainingBytes
- usagePercent
- stale 상태

## 상태별 디자인

### 정상
원형 progress ring.

### 데이터 한도 미설정

```text
이번 달
72.4 GB 사용

앱을 열어
한도를 설정하세요
```

### stale

하단 작은 점/텍스트:

`업데이트 필요`

---

# 3. Medium Widget — Light

```text
┌──────────────────────────────┐
│ ▂▄▆ 모바일 데이터       10/1 │
│                              │
│ 87.6 GB 남음                 │
│ ████████░░░░░░               │
│ 72.4 / 160 GB 사용 (45%)     │
│                              │
│ ┌───────────┐ ┌───────────┐ │
│ │📱 iPhone  │ │🔗 핫스팟  │ │
│ │54.2 GB    │ │18.2 GB    │ │
│ └───────────┘ └───────────┘ │
└──────────────────────────────┘
```

## Hotspot 미지원 variant

오른쪽 카드:

```text
오늘 사용
1.2 GB
```

핫스팟 카드를 억지로 표시하지 않는다.

---

# 4. Medium Widget — Dark

```text
┌──────────────────────────────┐
│ 데이터 사용량               │
│                              │
│ 72.4 GB              45%    │
│ / 160 GB                     │
│ █████████░░░░░               │
│                              │
│ 📱 iPhone             54.2 GB│
│ 🔗 Hotspot            18.2 GB│
└──────────────────────────────┘
```

---

# 5. Lock Screen Circular

## Variant A — Remaining

```text
╭───────╮
│ 87.6  │
│  GB   │
╰───────╯
```

Gauge ring 이용.

## Variant B — Percent

```text
╭───────╮
│  45%  │
╰───────╯
```

---

# 6. Lock Screen Rectangular

```text
▂▄▆ 데이터
87.6 GB 남음
45% 사용
```

또는 unlimited:

```text
▂▄▆ 이번 달
72.4 GB 사용
```

---

# 7. Timeline Model

```swift
struct UsageWidgetEntry: TimelineEntry {
    let date: Date
    let usedBytes: Int64
    let limitBytes: Int64?
    let remainingBytes: Int64?
    let usagePercent: Double?
    let iPhoneBytes: Int64?
    let hotspotBytes: Int64?
    let hotspotSupport: HotspotSupportState
    let lastMeasuredAt: Date
    let isStale: Bool
}
```

---

# 8. Shared Storage

Widget extension은 직접 DB 로직을 중복 구현하지 않는다.

App Group:

```text
group.com.example.DataView
```

권장 공유 값:

```text
summary.usedBytes
summary.limitBytes
summary.remainingBytes
summary.usagePercent
summary.iPhoneBytes
summary.hotspotBytes
summary.hotspotSupport
summary.lastMeasuredAt
summary.periodStart
summary.periodEnd
```

---

# 9. Widget Refresh

WidgetKit 업데이트는 실시간이 아니다.

원칙:

1. 앱에서 새 측정 완료
2. App Group summary 저장
3. `WidgetCenter.shared.reloadTimelines(ofKind:)`
4. Widget은 저장된 summary만 렌더

Widget 자체에서 초단위 폴링 금지.

---

# 10. Deep Link

위젯 탭:

```text
dataview://dashboard
```

핫스팟 카드 탭이 가능한 구성에서는:

```text
dataview://hotspot
```

통계:

```text
dataview://statistics
```

---

# 11. Privacy

Lock Screen 위젯에서는 사용자가 정보 노출을 원하지 않을 수 있다.

설정:

```text
잠금화면에서
[ ] 구체적인 GB 표시
[✓] 사용률만 표시
```

향후 적용 가능.

---

# 12. Widget Acceptance

- 숫자 잘림 없음
- 999 GB 이상에서도 레이아웃 유지
- 0 B에서 crash 없음
- unlimited 모드 대응
- hotspot unsupported 대응
- light/dark 대응
- Dynamic Type 확대 시 핵심 숫자는 유지
