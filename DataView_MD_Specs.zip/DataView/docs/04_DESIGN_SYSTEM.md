# DataView Design System

> 아래 색상은 현재 확정 시안을 개발에 옮기기 위한 근사 토큰이다. 실제 구현 후 iPhone 실기기 스크린샷 기준으로 미세 조정한다.

---

# 1. Brand

## Logo

3개의 세로 막대.

```text
▂ ▄ ▆
```

의미:

- network
- usage
- signal
- statistics

---

# 2. Color Tokens

## Light

```text
brandBlue        #2F80ED
brandBlueStrong  #1769E0
brandCyan        #45B8F5
hotspotGreen     #35C982

background       #F4F8FC
surface          #FFFFFF
surfaceSecondary #EEF4FA

textPrimary      #101828
textSecondary    #667085
textTertiary     #98A2B3

divider          #E4EAF0
track            #DCE4EC

warning          #F5A524
danger           #E5484D
```

## Dark

```text
backgroundDark   #08111D
surfaceDark      #101B28
surfaceDark2     #172433

textOnDark       #F7FAFC
textOnDarkMuted  #AAB6C3

trackDark        #344150
```

---

# 3. Semantic Colors

```text
cellular = brandBlue
hotspot  = hotspotGreen
remaining = brandBlue / brandCyan gradient
warning = warning
critical = danger
```

셀룰러와 핫스팟의 구분은 색상만으로 하지 않는다.

반드시:

- 아이콘
- 텍스트 label
- 색상

3가지를 함께 사용.

---

# 4. Gradient

Main splash:

```text
top    #B9DCFF
middle #DCEEFF
bottom #EEF6FF
```

Progress ring:

```text
start brandCyan
end   brandBlue
```

Hotspot:

```text
start #52D99A
end   #20B878
```

---

# 5. Typography

SF Pro / system font.

SwiftUI:

```swift
.font(.system(...))
```

외부 폰트 사용하지 않는다.

## Scale

```text
Hero Number      36 / semibold
Widget Hero      32 / bold
Title 1          28 / bold
Title 2          22 / semibold
Headline         17 / semibold
Body             16 / regular
Callout          15 / regular
Caption          12 / regular
Widget Caption   11 / medium
```

숫자는 가능하면 monospaced digits:

```swift
.monospacedDigit()
```

---

# 6. Spacing

4pt grid.

```text
xs  4
s   8
m   12
l   16
xl  20
2xl 24
3xl 32
```

---

# 7. Radius

```text
smallCard   12
card        16
largeCard   20
widget      system controlled
button      14
pill        999
```

---

# 8. Shadows

최소화.

Light card:

```text
y: 4
blur: 16
opacity: 0.06
```

Widget 내부에는 custom shadow를 거의 사용하지 않는다.

---

# 9. Components

## UsageRing

Props:

```text
progress: 0...1
centerPrimary
centerSecondary
style: cellular | hotspot | neutral
```

## UsageCard

```text
icon
title
value
percentage?
status?
```

## UsageBar

```text
label
value
percent
colorSemantic
```

## MetricTile

```text
title
value
caption?
icon?
```

## PeriodSegmentedControl

```text
일별 | 주별 | 월별
```

## PrimaryButton

```text
height 52
radius 14
full width
brandBlue
white text
```

---

# 10. Iconography

SF Symbols 우선.

권장:

```text
cellular        antenna.radiowaves.left.and.right
phone           iphone
hotspot         personalhotspot
statistics      chart.bar.fill
home            house.fill
settings        gearshape
notification    bell
privacy         lock.shield
refresh         arrow.clockwise
```

---

# 11. Motion

- 기본 transition: 200~300ms
- 숫자 갱신: subtle content transition
- chart: 300ms 이하
- 과도한 bounce 금지
- Reduce Motion 활성화 시 scale/bounce 제거

---

# 12. Empty / Error State

## No Limit

```text
이번 달 12.4 GB 사용

데이터 한도를 설정하면
남은 데이터도 확인할 수 있어요.

[요금제 설정]
```

## Measurement Unsupported

```text
핫스팟 분리 측정을
지원하지 않는 환경입니다.

셀룰러 전체 사용량은
계속 확인할 수 있습니다.
```

## Stale

```text
최근 측정값
20:14 기준

[새로고침]
```

---

# 13. Accessibility

- WCAG contrast 최대한 준수
- VoiceOver label 직접 지정
- 원형 게이지는 시각 정보만 제공하지 말 것

예:

```text
VoiceOver:
"이번 달 데이터. 160기가바이트 중 72.4기가바이트 사용. 45퍼센트."
```

- Dynamic Type 대응
- 색각 이상에서도 셀룰러/핫스팟 구분 가능
