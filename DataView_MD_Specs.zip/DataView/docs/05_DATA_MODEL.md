# DataView Data Model

## 1. PlanSettings

```swift
struct PlanSettings: Codable, Equatable {
    var dataLimitBytes: Int64?
    var resetDay: Int
    var isUnlimited: Bool

    var alert50: Bool
    var alert80: Bool
    var alert90: Bool

    var createdAt: Date
    var updatedAt: Date
}
```

---

# 2. InterfaceCounterSnapshot

원시 인터페이스 카운터 저장.

```swift
struct InterfaceCounterSnapshot: Codable, Identifiable {
    let id: UUID
    let measuredAt: Date

    let interfaceName: String
    let receivedBytes: UInt64
    let sentBytes: UInt64

    let classification: InterfaceClassification
}
```

```swift
enum InterfaceClassification: String, Codable {
    case cellular
    case wifi
    case hotspotCandidate
    case vpn
    case loopback
    case unknown
}
```

---

# 3. UsageSample

앱이 계산한 델타.

```swift
struct UsageSample: Codable, Identifiable {
    let id: UUID
    let from: Date
    let to: Date

    let cellularBytes: Int64
    let hotspotBytes: Int64?

    let measurementQuality: MeasurementQuality
}
```

```swift
enum MeasurementQuality: String, Codable {
    case verified
    case estimated
    case partial
    case unavailable
}
```

MVP에서 `estimated` 값은 기본 UI에 수치로 노출하지 않는 것을 권장.

---

# 4. DailyUsage

```swift
struct DailyUsage: Codable, Identifiable {
    let id: Date   // day start

    var cellularBytes: Int64
    var hotspotBytes: Int64?

    var totalBytes: Int64
}
```

---

# 5. BillingPeriodUsage

```swift
struct BillingPeriodUsage: Codable {
    let start: Date
    let end: Date

    let usedBytes: Int64
    let dataLimitBytes: Int64?

    let iPhoneBytes: Int64?
    let hotspotBytes: Int64?

    var remainingBytes: Int64? {
        guard let limit = dataLimitBytes else { return nil }
        return max(0, limit - usedBytes)
    }
}
```

---

# 6. WidgetSummary

App Group 전용 경량 모델.

```swift
struct WidgetSummary: Codable {
    let generatedAt: Date

    let periodStart: Date
    let periodEnd: Date

    let usedBytes: Int64
    let limitBytes: Int64?
    let remainingBytes: Int64?
    let usagePercent: Double?

    let iPhoneBytes: Int64?
    let hotspotBytes: Int64?
    let hotspotSupportState: HotspotSupportState

    let todayBytes: Int64
}
```

---

# 7. HotspotSupportState

```swift
enum HotspotSupportState: String, Codable {
    case unsupported
    case experimental
    case verified
}
```

UI 원칙:

```text
unsupported → 수치 숨김
experimental → 디버그/테스트 빌드에서만 수치 표시
verified → 일반 사용자 표시 허용
```

---

# 8. Counter Delta Algorithm

```text
previous = 10,000
current  = 12,500

delta = 2,500
```

카운터 감소:

```text
previous = 12,500
current  = 800

current < previous
→ counter reset로 간주
→ delta = current
→ quality = partial
```

단, 재부팅 사이에 발생한 트래픽은 완전 복원 불가.

---

# 9. Storage

권장 분리:

```text
SwiftData
├─ DailyUsage
├─ UsageSample
└─ diagnostics(optional)

UserDefaults
└─ PlanSettings

App Group UserDefaults
└─ WidgetSummary
```

원시 snapshot은 최신값 위주로만 유지하여 저장 공간 증가 방지.

---

# 10. Byte Formatting

```text
0...999 KB     → MB 이하
1.2 GB
72.4 GB
160 GB
1.02 TB
```

표시 규칙:

- 큰 숫자: 최대 소수 1자리
- 10 MB 미만: MB
- 1 GB 이상: GB
- locale 반영

Swift에서는 `ByteCountFormatter` 또는 자체 formatter 사용.
