# DataView iOS Architecture

## 1. Architecture

```text
SwiftUI Views
    ↓
ViewModels / Observable Models
    ↓
Domain Services
    ├─ UsageMeasurementService
    ├─ BillingPeriodService
    ├─ WidgetSyncService
    ├─ NotificationService
    └─ HotspotCapabilityService
    ↓
Repositories
    ├─ SettingsRepository
    ├─ UsageRepository
    └─ WidgetSummaryRepository
    ↓
System / Storage
    ├─ getifaddrs()
    ├─ SwiftData
    ├─ UserDefaults
    ├─ App Group
    ├─ WidgetKit
    └─ BackgroundTasks
```

MVVM 또는 lightweight unidirectional state를 사용한다.

---

# 2. Xcode Targets

```text
DataView
├─ DataViewApp
└─ DataViewWidgets
```

Optional future:

```text
DataViewTests
DataViewUITests
```

---

# 3. Suggested Folder Structure

```text
DataView/
├─ App/
│  ├─ DataViewApp.swift
│  ├─ RootView.swift
│  └─ AppRouter.swift
│
├─ Features/
│  ├─ Onboarding/
│  ├─ Dashboard/
│  ├─ Statistics/
│  ├─ Hotspot/
│  └─ Settings/
│
├─ Core/
│  ├─ Measurement/
│  │  ├─ NetworkCounterReader.swift
│  │  ├─ InterfaceClassifier.swift
│  │  ├─ UsageMeasurementService.swift
│  │  └─ HotspotCapabilityService.swift
│  │
│  ├─ Billing/
│  │  └─ BillingPeriodService.swift
│  │
│  ├─ Storage/
│  │  ├─ UsageRepository.swift
│  │  ├─ SettingsRepository.swift
│  │  └─ WidgetSummaryRepository.swift
│  │
│  ├─ Notifications/
│  │  └─ UsageNotificationService.swift
│  │
│  └─ Formatting/
│     └─ DataAmountFormatter.swift
│
├─ DesignSystem/
│  ├─ Tokens/
│  ├─ Components/
│  └─ Assets.xcassets
│
└─ Shared/
   ├─ Models/
   └─ Extensions/

DataViewWidgets/
├─ DataViewWidgetBundle.swift
├─ SmallUsageWidget.swift
├─ MediumUsageWidget.swift
├─ LockScreenUsageWidget.swift
└─ WidgetTimelineProvider.swift
```

---

# 4. NetworkCounterReader

C API wrapper.

Pseudo implementation:

```swift
protocol NetworkCounterReading {
    func readCounters() throws -> [NetworkInterfaceCounter]
}
```

```swift
struct NetworkInterfaceCounter {
    let name: String
    let receivedBytes: UInt64
    let sentBytes: UInt64

    var totalBytes: UInt64 {
        receivedBytes + sentBytes
    }
}
```

주의:

- null pointer 검사
- AF_LINK / sockaddr_dl 계열 데이터 확인
- `if_data64` 사용 가능 여부 확인
- integer overflow 방어
- interface 이름 하드코딩 최소화

---

# 5. InterfaceClassifier

예시 규칙은 구현 세부사항이며 OS 계약으로 간주하지 않는다.

```text
lo*      → loopback
en*      → wifi/ethernet candidate
pdp_ip*  → cellular candidate
utun*    → vpn/tunnel
others   → unknown
```

`pdp_ip0` 하나만 존재한다고 가정하지 않는다.

모든 `pdp_ip*` 후보를 수집한 뒤 실기기 검증을 거친다.

---

# 6. UsageMeasurementService

Responsibilities:

1. 현재 snapshot 읽기
2. 이전 snapshot 조회
3. interface별 delta 계산
4. reset 탐지
5. 분류별 합산
6. UsageSample 저장
7. DailyUsage 갱신
8. WidgetSummary 생성
9. Widget timeline reload

Pseudo:

```text
measure()
  current = reader.readCounters()
  previous = repository.latestSnapshot()

  delta = calculateDelta(previous, current)
  classified = classify(delta)

  save(classified)
  saveSnapshot(current)

  summary = buildWidgetSummary()
  widgetSync.save(summary)
  widgetSync.reload()
```

---

# 7. BillingPeriodService

```swift
func currentPeriod(
    now: Date,
    resetDay: Int,
    calendar: Calendar
) -> DateInterval
```

월별 날짜가 존재하지 않는 경우:

```text
resetDay 31
2월 → 말일 처리
```

정책을 일관되게 적용한다.

---

# 8. WidgetSyncService

```swift
protocol WidgetSyncing {
    func write(summary: WidgetSummary) throws
    func reload()
}
```

저장:

```swift
UserDefaults(
    suiteName: "group.com.example.DataView"
)
```

필요하면 JSON encode.

---

# 9. Background Tasks

목적:

- 가능한 시점에 snapshot 갱신
- 알림 상태 갱신
- WidgetSummary 갱신

주의:

BackgroundTasks는 정확한 주기 실행을 보장하지 않는다.

따라서 앱 논리는:

```text
"15분마다 반드시 실행"
```

을 전제로 설계하지 않는다.

---

# 10. App Lifecycle Sampling

다음 시점에 `measure()` 호출:

- app launch
- foreground 진입
- background 진입 직전
- 사용자가 pull-to-refresh
- background refresh 기회
- 설정 변경 후

---

# 11. Widget Security

App Group에 저장하는 정보는 최소화.

저장 금지:

- 통신사 계정 자격증명
- 개인 식별 정보
- 임의의 기기 MAC address
- 불필요한 raw network metadata

---

# 12. Error Handling

```swift
enum MeasurementError: Error {
    case interfaceReadFailed
    case invalidCounter
    case storageFailed
}
```

사용자 UI에서는 기술 오류 코드 대신:

`데이터 사용량을 갱신하지 못했습니다.`

버튼:

`다시 시도`

---

# 13. Feature Flags

```swift
struct FeatureFlags {
    static let hotspotBreakdown = false
    static let hotspotDevices = false
}
```

실기기 QA가 끝나기 전에는 production에서 켜지 않는다.
