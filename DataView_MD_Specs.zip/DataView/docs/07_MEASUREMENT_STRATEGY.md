# DataView Measurement Strategy

이 문서는 앱의 가장 중요한 기술적 리스크를 정의한다.

---

# 1. 목표

다음 값을 계산한다.

```text
현재 주기 전체 셀룰러 사용량
오늘 셀룰러 사용량
최근 7일 사용량
남은 데이터
사용률
핫스팟 사용량 — 검증 가능한 경우
```

---

# 2. 셀룰러 카운터

iOS/Darwin 네트워크 인터페이스 통계를 통해 시스템 차원의 인터페이스 바이트 카운터를 읽는다.

개념:

```text
cellular_total =
Σ(receivedBytes + sentBytes)
for cellularCandidateInterfaces
```

중요:

이 카운터는 **통신사의 과금 카운터가 아니다.**

---

# 3. 앱이 저장해야 하는 이유

시스템 카운터를 그대로 `이번 달 사용량`으로 표시하면 안 된다.

DataView는 snapshot 차이를 누적한다.

```text
09:00  100 GB
12:00  101 GB

DataView delta
= 1 GB
```

그 델타를 현재 billing period에 추가한다.

---

# 4. First Launch

첫 실행 시 과거 데이터는 알 수 없다.

정책:

```text
첫 snapshot = baseline
사용량 = 0
```

사용자에게:

`DataView 설치 후 사용량부터 측정됩니다.`

선택적으로 `현재 통신사 사용량 입력` 기능을 제공할 수 있다.

예:

```text
현재까지 사용한 데이터
[ 24.5 ] GB
```

이를 `manualAdjustmentBytes`로 저장하면 월간 잔량을 현실적으로 맞출 수 있다.

---

# 5. Reboot Handling

문제:

재부팅 시 인터페이스 카운터가 감소/초기화될 수 있다.

탐지:

```text
current < previous
```

처리:

```text
delta = current
quality = partial
```

하지만:

```text
last sample
→ 트래픽 발생
→ reboot
→ next sample
```

사이의 일부 트래픽은 복원할 수 없다.

따라서 앱에 `앱 측정 기준` 라벨을 둔다.

---

# 6. Counter Overflow

항상 64-bit counter를 우선 사용한다.

Swift 내부 누적은:

```text
UInt64 for raw counters
Int64 for validated persisted deltas
```

범위 변환 시 overflow 검사.

---

# 7. Cellular Interface Classification

관찰상 iOS에서 cellular interface가 `pdp_ip*` 형태로 나타날 수 있다.

하지만:

- 이름은 공식적인 안정 API 계약으로 간주하지 않는다.
- SIM 하나 = interface 하나라고 가정하지 않는다.
- Dual SIM을 고려한다.
- 새로운 interface 이름은 진단 로그에 기록한다.

구현:

```text
1. 모든 interface enumerating
2. cellular candidates 추출
3. 테스트 데이터 수집
4. allow-list + diagnostics
```

---

# 8. VPN / Private Relay

`utun*` 같은 tunnel interface는 셀룰러와 중복 집계될 위험이 있다.

MVP 원칙:

- tunnel traffic을 cellular total에 별도로 더하지 않는다.
- 기본 physical/cellular 후보 카운터 중심으로 계산한다.
- VPN 사용 전/후 실기기 검증 필요.

---

# 9. Hotspot Measurement

가장 주의해야 하는 영역.

## 공식 상태

서드파티 앱이 시스템 설정의 Personal Hotspot 기기별 데이터 사용량을 직접 가져오는 일반 공개 API는 전제로 하지 않는다.

`NEHotspotHelper`는 개인용 핫스팟 데이터 측정 API가 아니라, Wi-Fi hotspot network 인증/연동 목적의 제한된 API다.

따라서 다음은 금지:

```text
"NEHotspotHelper로 개인용 핫스팟 사용량 읽기"
```

---

# 10. Hotspot Capability Strategy

```swift
protocol HotspotUsageProviding {
    func currentSupportState() -> HotspotSupportState
    func readHotspotUsage() async throws -> Int64?
}
```

초기 구현:

```text
state = unsupported
value = nil
```

이후 실험 branch에서 인터페이스 변화를 분석.

### 검증 조건

핫스팟을 켜고 MacBook으로 대용량 파일을 내려받았을 때:

```text
A. cellular total 증가
B. 특정 hotspot candidate 증가
C. iPhone 자체 traffic과 분리 가능
```

여러 기기/OS에서 재현되어야 `verified`.

---

# 11. 절대 하지 말 것

- Private API
- 설정 앱 database 직접 읽기
- sandbox 우회
- undocumented entitlement 사용
- Network Extension을 데이터 카운터 하나 때문에 억지로 VPN으로 구성
- Packet Tunnel을 일반 데이터 측정 기능으로 오해하도록 사용자에게 표현

---

# 12. Hotspot UI States

### unsupported

```text
핫스팟
분리 측정 미지원
```

### experimental

TestFlight/internal only:

```text
핫스팟
18.2 GB
실험적 측정
```

### verified

```text
핫스팟
18.2 GB
```

---

# 13. Manual Calibration

오차 관리에 매우 유용.

설정:

```text
현재 통신사 표시 사용량
24.5 GB
```

앱:

```text
measuredSinceCalibration = 8.2 GB
manualBase = 24.5 GB

displayUsage = 32.7 GB
```

이 기능을 P1로 권장.

---

# 14. Accuracy Label

Dashboard 하단:

```text
앱 측정 기준 · 최근 갱신 20:14
```

정보 버튼:

```text
DataView는 iPhone의 네트워크 인터페이스 사용량을 기반으로 계산합니다.
통신사 과금 기준과 차이가 날 수 있습니다.
```

---

# 15. QA Matrix

필수 실기기 테스트:

```text
Wi-Fi ON / Cellular ON
Wi-Fi OFF / Cellular ON
Airplane mode
Dual SIM
Personal Hotspot ON
Personal Hotspot OFF
VPN ON
VPN OFF
Device reboot
App force quit
Low Power Mode
Widget installed
Widget not installed
```

테스트 시 각 단계의 raw interface counter snapshot 저장.
