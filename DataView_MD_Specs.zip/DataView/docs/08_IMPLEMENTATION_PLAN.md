# DataView Implementation Plan for Codex

## 기본 지시

- SwiftUI로 작성
- iOS 17+
- Apple 공개 API만 사용
- 화면부터 fake data로 완성한 후 측정 엔진 연결
- Hotspot 분리는 feature flag로 시작
- 모든 단계에서 build 가능한 상태 유지

---

# Phase 0 — Project Bootstrap

## Tasks

- [ ] `DataView` iOS App 생성
- [ ] `DataViewWidgets` Widget Extension 추가
- [ ] App Group capability 추가
- [ ] Notification capability 추가
- [ ] SwiftData container 구성
- [ ] 폴더 구조 구성
- [ ] Color/Spacing/Typography tokens 구현

완료 조건:

```text
App build success
Widget build success
Preview success
```

---

# Phase 1 — Static UI

실측 기능을 연결하지 않는다.

## 화면

- [ ] SplashView
- [ ] OnboardingView
- [ ] PlanSetupView
- [ ] DashboardView
- [ ] StatisticsView
- [ ] HotspotDetailView
- [ ] SettingsView
- [ ] MeasurementStatusView

Fake model:

```swift
WidgetSummary(
  usedBytes: 72.4 GB,
  limitBytes: 160 GB,
  remainingBytes: 87.6 GB,
  usagePercent: 0.4525,
  iPhoneBytes: 54.2 GB,
  hotspotBytes: 18.2 GB
)
```

**주의:** mock 값은 Preview/Debug 전용.

---

# Phase 2 — Design System Components

- [ ] `UsageRing`
- [ ] `MetricCard`
- [ ] `UsageBar`
- [ ] `DataAmountText`
- [ ] `PeriodPicker`
- [ ] `EmptyStateCard`
- [ ] `MeasurementStatusBadge`

Snapshot preview 작성.

---

# Phase 3 — Settings + Billing Period

- [ ] PlanSettings 저장
- [ ] resetDay 검증
- [ ] current billing period 계산
- [ ] 28/29/30/31일 edge case
- [ ] unlimited mode
- [ ] manual calibration placeholder

Unit tests:

```text
reset day 1
reset day 15
reset day 31 in February
year boundary
```

---

# Phase 4 — Network Counter Reader

## 구현

- [ ] `getifaddrs()` wrapper
- [ ] interface counter model
- [ ] 64-bit bytes
- [ ] classifier
- [ ] diagnostic dump

Debug screen에서:

```text
name
rx
tx
total
classification
```

확인 가능해야 함.

---

# Phase 5 — Delta Engine

- [ ] snapshot persistence
- [ ] normal delta
- [ ] reset delta
- [ ] negative prevention
- [ ] daily aggregation
- [ ] billing aggregation

Unit tests:

```text
100 → 120 = 20
120 → 5 = reset, delta 5
same = 0
multi interfaces sum
unknown excluded
```

---

# Phase 6 — Dashboard Real Data

- [ ] fake model 제거
- [ ] UsageMeasurementService 연결
- [ ] foreground refresh
- [ ] manual refresh
- [ ] lastMeasuredAt
- [ ] error state
- [ ] no plan state

---

# Phase 7 — Widgets

- [ ] App Group summary
- [ ] Small
- [ ] Medium Light/Dark automatic
- [ ] accessoryCircular
- [ ] accessoryRectangular
- [ ] timeline provider
- [ ] deep link
- [ ] stale state

---

# Phase 8 — Notifications

- [ ] request permission
- [ ] 50 threshold
- [ ] 80 threshold
- [ ] 90 threshold
- [ ] one notification per billing period per threshold
- [ ] period reset clears threshold sent states

---

# Phase 9 — Background Refresh

- [ ] BGTask registration
- [ ] measurement attempt
- [ ] widget summary refresh
- [ ] never assume exact execution interval

---

# Phase 10 — Hotspot Research Build

Production 기본:

```swift
FeatureFlags.hotspotBreakdown = false
```

Internal build:

- [ ] raw interface diffs before hotspot
- [ ] hotspot on diff
- [ ] client traffic diff
- [ ] hotspot off diff
- [ ] device matrix
- [ ] iOS version matrix

성공 후에만:

```swift
FeatureFlags.hotspotBreakdown = true
```

---

# Phase 11 — Statistics

- [ ] daily graph
- [ ] weekly graph
- [ ] monthly graph
- [ ] iPhone/hotspot ratio when available
- [ ] zero-day handling
- [ ] empty state

Swift Charts 사용 권장.

---

# Phase 12 — Polish

- [ ] VoiceOver
- [ ] Dynamic Type
- [ ] Reduce Motion
- [ ] dark mode
- [ ] localization-ready strings
- [ ] haptics 최소 적용
- [ ] first launch copy
- [ ] privacy copy

---

# Codex Rules

Codex에게 다음 원칙을 유지하도록 한다.

```text
1. private API를 사용하지 마라.
2. Personal Hotspot 기기 목록을 임의 추정하지 마라.
3. hotspot 값이 검증되지 않았다면 UI에 숫자를 표시하지 마라.
4. getifaddrs 결과의 interface name을 절대 단일 이름으로 고정 가정하지 마라.
5. 모든 raw counter 계산에서 overflow/reset을 처리하라.
6. widget은 shared summary를 읽도록 하라.
7. 사용자 데이터는 기본적으로 로컬에만 저장하라.
8. 한 단계가 끝날 때마다 build/test 가능한 상태를 유지하라.
```

---

# 첫 Codex 작업 프롬프트 예시

```text
Read all markdown specifications in /docs before changing code.

Start with Phase 0 and Phase 1 only.

Create an iOS 17+ SwiftUI app named DataView and a WidgetKit extension.
Implement the design system and static screens based on the wireframes.

Use debug-only mock usage data:
72.4 GB used / 160 GB,
87.6 GB remaining,
54.2 GB iPhone,
18.2 GB hotspot.

Do not implement real network measurement yet.
Do not use private APIs.
The app and widget extension must build successfully.
```
