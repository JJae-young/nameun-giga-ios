# DataView Acceptance Tests

# 1. Onboarding

### AT-001
첫 설치 시 Splash 후 Onboarding 표시.

### AT-002
온보딩 완료 후 재실행하면 Dashboard 직행.

### AT-003
월 데이터 한도가 저장됨.

---

# 2. Billing Period

### AT-010

Input:

```text
resetDay = 1
now = 2026-09-14
```

Expected:

```text
start = 2026-09-01
end   = 2026-10-01
```

### AT-011

```text
resetDay = 15
now = 2026-09-14
```

Expected:

```text
start = 2026-08-15
end   = 2026-09-15
```

### AT-012

resetDay 31 + February에서 crash 없음.

---

# 3. Usage Calculation

### AT-020

```text
previous = 1000
current  = 1600
```

Expected:

```text
delta = 600
```

### AT-021 — Counter reset

```text
previous = 1000
current  = 100
```

Expected:

```text
delta = 100
quality = partial
```

### AT-022

Unknown interfaces는 기본 cellular total에 포함되지 않음.

---

# 4. Dashboard

### AT-030

```text
limit = 160 GB
used = 72.4 GB
```

Expected approximately:

```text
remaining = 87.6 GB
usagePercent = 45.25%
```

UI rounded display:

```text
87.6 GB 남음
45% 사용
72.4 / 160 GB
```

### AT-031

used > limit인 경우 remaining은 음수가 되지 않음.

```text
remaining = 0
```

Progress는 100% max로 clamp.

---

# 5. Hotspot

### AT-040

state = unsupported

Expected:

- hotspot numeric value hidden
- Dashboard layout remains valid
- no fake data

### AT-041

state = experimental + production build

Expected:

- hotspot numeric value hidden

### AT-042

state = verified

Expected:

- hotspot value visible

---

# 6. Widget

### AT-050

Small widget:

- remaining
- percent
- no clipping

### AT-051

Medium widget hotspot unsupported:

- second card falls back to Today Usage

### AT-052

Dark mode legible.

### AT-053

App measurement update triggers Widget timeline reload.

---

# 7. Reboot

### AT-060

기기 재부팅 후 첫 앱 launch:

- crash 없음
- negative usage 없음
- measurement quality can become partial
- new baseline stored

---

# 8. Notifications

### AT-070

79% → 81%

80% notification once.

### AT-071

81% → 82%

additional 80% notification 없음.

### AT-072

새 billing period 시작 후 80% sent state reset.

---

# 9. Manual Calibration

### AT-080

```text
carrierBase = 24.5 GB
appMeasured = 8.2 GB
```

Expected:

```text
display = 32.7 GB
```

---

# 10. Accessibility

### AT-090

VoiceOver reads:

```text
"이번 달 데이터. 160기가바이트 중 72.4기가바이트 사용. 45퍼센트."
```

### AT-091

Large Dynamic Type에서 핵심 숫자 잘리지 않음.

---

# 11. Privacy

### AT-100

기본 설치 상태에서 서버로 usage 데이터 전송 없음.

### AT-101

Widget App Group에 불필요한 raw interface metadata 저장하지 않음.

---

# 12. App Store Safety Review

Release candidate에서 확인:

- [ ] private API 없음
- [ ] undocumented entitlement 없음
- [ ] HotspotHelper를 개인용 핫스팟 측정 목적으로 오용하지 않음
- [ ] VPN 기능 없이 Network Extension entitlement 추가하지 않음
- [ ] 측정값을 carrier official usage라고 표현하지 않음
